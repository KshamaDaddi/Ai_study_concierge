import sqlite3
import json
from config import DB_PATH

class MemoryManager:
    """
    Handles persistent storage for user goals, plans, and progress using SQLite.
    """
    def __init__(self):
        self.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        self.cursor = self.conn.cursor()
        self._setup_db()

    def _setup_db(self):
        """Creates the necessary tables if they don't exist."""
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                user_goal TEXT,
                preferences TEXT,
                current_plan TEXT,
                progress_log TEXT
            )
        """)
        self.conn.commit()

    def get_session_data(self, session_id: str) -> dict:
        """Retrieves all data for a given session."""
        self.cursor.execute("SELECT user_goal, preferences, current_plan, progress_log FROM sessions WHERE session_id = ?", (session_id,))
        row = self.cursor.fetchone()
        if not row:
            return {"user_goal": "", "preferences": {}, "current_plan": {}, "progress_log": []}
        
        return {
            "user_goal": row[0],
            "preferences": json.loads(row[1] or "{}"),
            "current_plan": json.loads(row[2] or "{}"),
            "progress_log": json.loads(row[3] or "[]"),
        }

    def update_session_data(self, session_id: str, data: dict):
        """Updates or inserts data for a session."""
        existing_data = self.get_session_data(session_id)
        
        # Merge new data with existing data
        user_goal = data.get("user_goal", existing_data["user_goal"])
        preferences = data.get("preferences", existing_data["preferences"])
        current_plan = data.get("current_plan", existing_data["current_plan"])
        progress_log = data.get("progress_log", existing_data["progress_log"])
        
        self.cursor.execute("""
            REPLACE INTO sessions (session_id, user_goal, preferences, current_plan, progress_log)
            VALUES (?, ?, ?, ?, ?)
        """, (
            session_id,
            user_goal,
            json.dumps(preferences),
            json.dumps(current_plan),
            json.dumps(progress_log)
        ))
        self.conn.commit()

    def close(self):
        self.conn.close()