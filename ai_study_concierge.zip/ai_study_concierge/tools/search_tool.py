from pydantic import BaseModel, Field
import json
import random

# --- Pydantic Schema for Tool Input ---
class SearchQuery(BaseModel):
    query: str = Field(description="The specific search query to get up-to-date or detailed information.")
    
# --- Tool Implementation ---
class SearchTool:
    """Simulates a web search for gathering factual information."""
    
    def web_search(self, search_query: SearchQuery):
        """
        Performs a simulated web search based on the query.
        
        :param search_query: The query to search for.
        :return: A JSON string containing simulated search results.
        """
        query = search_query.query
        
        # Simple keyword-based simulation
        if "GATE" in query or "Data Science" in query:
            result = f"Top-rated resources for '{query}': 'ISRO's GATE notes (PDF)', 'NPTEL course on ML', 'Standard textbook on DBMS'. Key topics include: Linear Algebra, Probability, ML Algorithms (Decision Trees, Clustering), and Python/Pandas."
        elif "ML Project" in query or "TensorFlow" in query:
            result = f"Latest trends for '{query}': Focus on RAG systems and using fine-tuned LLaMA models. Recommended starting points: Image Classification with Keras or Time-Series Forecasting with PyTorch."
        elif "Python" in query:
            result = f"Key Python libraries for Data Science are Pandas, NumPy, Scikit-learn, and Matplotlib. Version 3.11 is the current standard."
        else:
            result = f"Simulated search result for '{query}': Found 3 relevant articles. The first one discusses the 'Pareto principle' applied to study planning, suggesting an 80/20 focus."

        return json.dumps({
            "status": "success",
            "query": query,
            "snippet": result,
            "source": f"Simulated-Web-Source-{random.randint(100, 999)}"
        })

# Register the tool function for the agent to use
search_tool_fns = [SearchTool().web_search]