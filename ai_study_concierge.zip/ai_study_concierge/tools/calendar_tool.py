import datetime
from pydantic import BaseModel, Field
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
import os
from config import CALENDAR_SCOPES, CALENDAR_CLIENT_SECRETS_FILE

# --- Pydantic Schema for Tool Input ---
class CalendarEvent(BaseModel):
    summary: str = Field(description="The title of the event (e.g., 'Study Linear Algebra', 'ML Project Checkpoint').")
    description: str = Field(description="Detailed description of the event, including tasks or context.")
    start_time: str = Field(description="Start time in ISO 8601 format (e.g., '2025-12-10T10:00:00').")
    end_time: str = Field(description="End time in ISO 8601 format (e.g., '2025-12-10T12:00:00').")

# --- Tool Implementation ---
class CalendarTool:
    def __init__(self):
        # NOTE: This part requires proper OAuth setup (client_secret.json)
        self.service = self._authenticate_calendar()
    
    def _authenticate_calendar(self):
        """Shows how to set up the Google Calendar service. Mocks it if credentials are missing."""
        creds = None
        token_path = 'token.json'
        
        if os.path.exists(token_path):
            creds = Credentials.from_authorized_user_file(token_path, CALENDAR_SCOPES)
        
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                try:
                    creds.refresh(Request())
                except Exception as e:
                    print(f"Token refresh failed: {e}. Falling back to simulation.")
                    return self._simulate_service()
            elif os.path.exists(CALENDAR_CLIENT_SECRETS_FILE):
                try:
                    flow = InstalledAppFlow.from_client_secrets_file(CALENDAR_CLIENT_SECRETS_FILE, CALENDAR_SCOPES)
                    creds = flow.run_local_server(port=0)
                    with open(token_path, 'w') as token:
                        token.write(creds.to_json())
                except Exception as e:
                    print(f"OAuth flow failed: {e}. Falling back to simulation.")
                    return self._simulate_service()
            else:
                print(f"'{CALENDAR_CLIENT_SECRETS_FILE}' not found. Calendar events will be simulated.")
                return self._simulate_service()
        
        if creds and creds.valid:
            return build('calendar', 'v3', credentials=creds)
        else:
            return self._simulate_service()

    def _simulate_service(self):
        """A mock object to simulate the Calendar service without real authentication."""
        class MockService:
            def events(self):
                class MockEvents:
                    def insert(self, calendarId, body):
                        class MockInsert:
                            def execute(self):
                                return {"id": "mock_event_123", "htmlLink": "https://mock.calendar/event"}
                        return MockInsert()
                return MockEvents()
        return MockService()

    def create_event(self, event_data: CalendarEvent):
        """
        Creates a new event on the user's Google Calendar.
        
        :param event_data: An instance of CalendarEvent containing event details.
        :return: A JSON string result of the operation.
        """
        try:
            event = {
                'summary': event_data.summary,
                'description': event_data.description,
                'start': {'dateTime': event_data.start_time, 'timeZone': 'Asia/Kolkata'}, # Adjust TimeZone as needed
                'end': {'dateTime': event_data.end_time, 'timeZone': 'Asia/Kolkata'},
            }
            
            # Using 'primary' for the default calendar
            result = self.service.events().insert(calendarId='primary', body=event).execute()
            
            if 'mock_event' in result.get('id', ''):
                return json.dumps({
                    "status": "success (SIMULATED)",
                    "message": f"Successfully planned: '{event_data.summary}' from {event_data.start_time} to {event_data.end_time}.",
                    "details": result
                })
            else:
                return json.dumps({
                    "status": "success",
                    "message": f"Successfully created event: {result.get('htmlLink')}",
                    "event_id": result.get('id')
                })

        except Exception as e:
            return json.dumps({"status": "error", "message": f"Failed to create event. Error: {e}"})

# Register the tool function for the agent to use
calendar_tool_fns = [CalendarTool().create_event]