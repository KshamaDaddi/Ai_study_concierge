from pydantic import BaseModel, Field
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import json
import os

# --- Pydantic Schema for Tool Input ---
class DocumentContent(BaseModel):
    title: str = Field(description="The main title of the document (e.g., 'GATE Prep 3-Month Plan').")
    sections: dict = Field(description="A dictionary where keys are section titles and values are their content.")
    filename: str = Field(description="The desired output filename (e.g., 'gate_plan.pdf').")

# --- Tool Implementation ---
class DocumentGenerator:
    """Simulates generating a PDF document for a study or project plan."""
    
    def generate_pdf(self, doc_content: DocumentContent):
        """
        Generates a PDF document with the plan summary.
        
        :param doc_content: An instance of DocumentContent with the plan.
        :return: A JSON string result indicating the file location.
        """
        output_dir = "generated_docs"
        os.makedirs(output_dir, exist_ok=True)
        file_path = os.path.join(output_dir, doc_content.filename)

        try:
            c = canvas.Canvas(file_path, pagesize=letter)
            c.drawString(100, 750, f"*** {doc_content.title} ***")
            y_pos = 730
            
            for section, content in doc_content.sections.items():
                y_pos -= 20
                if y_pos < 50: # Page break logic
                    c.showPage()
                    y_pos = 750
                
                c.setFont("Helvetica-Bold", 12)
                c.drawString(100, y_pos, section)
                y_pos -= 15
                
                c.setFont("Helvetica", 10)
                # Simple text wrapping simulation
                for line in str(content).split('\n'):
                    c.drawString(110, y_pos, line[:80])
                    y_pos -= 12
            
            c.save()
            return json.dumps({
                "status": "success",
                "message": f"Plan document generated successfully at: {file_path}",
                "file_path": file_path
            })
        except Exception as e:
            return json.dumps({"status": "error", "message": f"PDF generation failed. Error: {e}"})

# Register the tool function for the agent to use
doc_generator_fns = [DocumentGenerator().generate_pdf]