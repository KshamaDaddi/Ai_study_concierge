import json
from agents.goal_analyzer import GoalAnalyzerAgent
from agents.study_planner import StudyPlannerAgent
from agents.project_builder import ProjectBuilderAgent
from agents.scheduler import SchedulerAgent
from agents.evaluator import ProgressEvaluatorAgent
from agents.meta_evaluator import MetaEvaluatorAgent
from memory.memory_manager import MemoryManager
import uuid
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Ensure the memory directory exists
os.makedirs("memory", exist_ok=True)
os.makedirs("generated_docs", exist_ok=True)

class StudyConcierge:
    def __init__(self):
        self.memory_manager = MemoryManager()
        self.agents = {
            "GoalAnalyzer": GoalAnalyzerAgent(),
            "StudyPlanner": StudyPlannerAgent(),
            "ProjectBuilder": ProjectBuilderAgent(),
            "Scheduler": SchedulerAgent(),
            "Evaluator": ProgressEvaluatorAgent(),
            "MetaEvaluator": MetaEvaluatorAgent()
        }
        self.initial_agent = "GoalAnalyzer"
    
    def run_workflow(self, session_id: str, user_prompt: str, start_agent: str = None) -> dict:
        """
        Executes the multi-agent workflow based on the current state and user input.
        
        :param session_id: Unique identifier for the user session.
        :param user_prompt: The initial or follow-up request from the user.
        :param start_agent: Optional agent to start the flow from (for resuming/re-planning).
        :return: Final result JSON from the Meta-Evaluator.
        """
        current_agent_name = start_agent if start_agent else self.initial_agent
        full_context = self.memory_manager.get_session_data(session_id)
        
        # Inject the user's latest prompt into the context for all agents
        full_context["latest_user_input"] = user_prompt
        
        print(f"--- Starting Workflow for Session: {session_id} ---")
        print(f"Initial Agent: {current_agent_name}")
        
        loop_counter = 0
        MAX_ITERATIONS = 6 # Prevent infinite loops
        
        while current_agent_name != "STOP" and loop_counter < MAX_ITERATIONS:
            loop_counter += 1
            print(f"\n[{loop_counter}/{MAX_ITERATIONS}] Executing Agent: {current_agent_name}")
            
            agent = self.agents.get(current_agent_name)
            if not agent:
                raise ValueError(f"Unknown agent: {current_agent_name}")

            # 1. Agent Execution
            # The prompt for the agent is often the output from the previous one,
            # but for the first agent, it's the user_prompt.
            
            # Use the previous agent's raw output as the prompt for the next agent
            agent_input = user_prompt if current_agent_name == self.initial_agent and loop_counter == 1 else full_context.get("last_agent_output", user_prompt)

            agent_output_json_str = agent.generate_response(agent_input, full_context)
            
            try:
                # Agent outputs a JSON string (mandatory for all agents)
                agent_output = json.loads(agent_output_json_str)
            except json.JSONDecodeError as e:
                print(f"ERROR: Agent {current_agent_name} returned invalid JSON: {agent_output_json_str}")
                agent_output = {"error": f"Invalid JSON output from agent: {e}"}

            # 2. Update Context
            full_context["last_agent_output"] = json.dumps(agent_output, indent=2)
            
            # --- META-EVALUATOR HANDLER ---
            if current_agent_name == "MetaEvaluator":
                # The MetaEvaluator determines the next step and memory update
                decision = agent_output # The output is the MetaEvaluationDecision schema
                
                # Update memory with new plan/progress data
                if decision.get("memory_update"):
                    self.memory_manager.update_session_data(session_id, decision["memory_update"])
                    
                # Set the next agent
                current_agent_name = decision.get("next_agent_to_call", "STOP")
                
                # The final user response is ready
                return decision
            
            # --- DEFAULT TRANSITION LOGIC (for non-Meta agents) ---
            # 1. Goal Analyzer -> Study Planner (or Project Builder if goal is purely project)
            if current_agent_name == "GoalAnalyzer":
                # Store the structured analysis in memory
                self.memory_manager.update_session_data(session_id, {"user_goal": agent_output.get("user_goal_summary", "No Goal"), "preferences": agent_output})
                full_context.update({"user_goal": agent_output.get("user_goal_summary"), "preferences": agent_output}) # Update in-memory context
                
                # Simple logic to choose next: assume study for now.
                current_agent_name = "StudyPlanner" 
                
            # 2. Study Planner / Project Builder -> Scheduler
            elif current_agent_name in ["StudyPlanner", "ProjectBuilder"]:
                # Store the generated plan in memory
                self.memory_manager.update_session_data(session_id, {"current_plan": agent_output})
                full_context.update({"current_plan": agent_output}) # Update in-memory context
                current_agent_name = "Scheduler"
                
            # 3. Scheduler -> Meta-Evaluator
            elif current_agent_name == "Scheduler":
                current_agent_name = "MetaEvaluator"
                
            # 4. Evaluator -> Meta-Evaluator (or Study Planner/Project Builder if adjustment needed)
            elif current_agent_name == "Evaluator":
                if agent_output.get("new_plan_adjustment_required", False):
                    # Trigger re-planning
                    print("EVALUATOR requested re-planning.")
                    current_agent_name = "StudyPlanner" # Assume StudyPlanner for re-planning
                else:
                    current_agent_name = "MetaEvaluator"
                
            else:
                # Should not happen in a defined flow
                current_agent_name = "MetaEvaluator" # Force to final agent for user response
                
        return {"final_user_response": "Workflow completed. Please check your calendar and generated documents."}

    def close(self):
        self.memory_manager.close()