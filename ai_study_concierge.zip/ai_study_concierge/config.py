import os
from pydantic import BaseModel

# --- Environment Setup ---
# You must set your API key in your environment variables
# e.g., in a .env file or directly in your shell/Colab notebook
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

# --- Model Configuration ---
# Use the fastest, most capable model for a multi-agent system
GEMINI_MODEL = "gemini-2.5-flash"
TEMPERATURE = 0.5

# --- System Configuration ---
DB_PATH = "memory/memory.db"
CALENDAR_SCOPES = ['https://www.googleapis.com/auth/calendar.events']
CALENDAR_CLIENT_SECRETS_FILE = "client_secret.json" # Required for Google Calendar API