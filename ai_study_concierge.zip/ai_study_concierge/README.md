# AI Study & Project Planner Concierge

A multi-agent system built with the Gemini API to intelligently plan study goals (like exam prep) or software projects, schedule tasks using the Google Calendar API, and monitor progress.

## 📁 FOLDER STRUCTURE
