import streamlit as st
from main import StudyConcierge
import uuid
import json

# Initialize the concierge
if 'concierge' not in st.session_state:
    st.session_state.concierge = StudyConcierge()
if 'session_id' not in st.session_state:
    st.session_state.session_id = str(uuid.uuid4())
if 'chat_history' not in st.session_state:
    st.session_state.chat_history = []

def display_chat_message(role, content):
    """Displays a chat message with the appropriate role."""
    st.session_state.chat_history.append({"role": role, "content": content})

def handle_user_input(user_input):
    """Processes user input through the multi-agent system."""
    if user_input:
        display_chat_message("user", user_input)
        
        with st.spinner("🚀 Running Multi-Agent Concierge..."):
            try:
                # Run the main workflow
                result = st.session_state.concierge.run_workflow(
                    session_id=st.session_state.session_id, 
                    user_prompt=user_input
                )
                
                # The final, user-friendly response comes from the MetaEvaluator
                final_response = result.get("final_user_response", "I've completed the planning process. Please check the logs for details.")
                
                # Display the final, polished response
                display_chat_message("assistant", final_response)
                
                # Display internal logs/memory updates for debugging/transparency
                with st.expander("📝 Planning Summary & Internal Log"):
                    st.json(result) # Show the raw MetaEvaluator output
                    memory_data = st.session_state.concierge.memory_manager.get_session_data(st.session_state.session_id)
                    st.subheader("Persistent Memory Snapshot")
                    st.json(memory_data)
                    
            except Exception as e:
                st.error(f"An unexpected error occurred during the agent run: {e}")
                display_chat_message("assistant", "I encountered a critical error while processing your request. Please check the console for details.")

# --- Streamlit UI ---
st.set_page_config(page_title="Study & Project Planner Concierge", layout="wide")

st.title("AI Study & Project Planner Concierge 🤖🗓️")
st.caption(f"Session ID: `{st.session_state.session_id}` | Model: `gemini-2.5-flash`")

# Sidebar for controls
with st.sidebar:
    st.header("Setup & Control")
    st.markdown("1. **Set `GEMINI_API_KEY`** in your environment.")
    st.markdown("2. **For Calendar:** Place `client_secret.json` in the root folder.")
    
    if st.button("Clear Session & History", use_container_width=True):
        st.session_state.session_id = str(uuid.uuid4())
        st.session_state.chat_history = []
        st.session_state.concierge.memory_manager.update_session_data(st.session_state.session_id, {"user_goal": "", "preferences": {}, "current_plan": {}, "progress_log": []})
        st.rerun()

# Display chat history
chat_container = st.container()
with chat_container:
    for message in st.session_state.chat_history:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

# User input form
user_input = st.chat_input("Enter your goal (e.g., 'Plan GATE Data Science prep in 3 months, 2hrs/day')")
if user_input:
    handle_user_input(user_input)