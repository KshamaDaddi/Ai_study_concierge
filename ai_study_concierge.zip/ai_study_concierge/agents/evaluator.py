from .base_agent import BaseAgent, BaseModel
from typing import Dict, Any

# --- Agent Output Schema ---
class EvaluationReport(BaseModel):
    status_summary: str
    next_steps_recommendation: str
    performance_metrics: Dict[str, Any]
    new_plan_adjustment_required: bool

class ProgressEvaluatorAgent(BaseAgent):
    def __init__(self):
        system_prompt = (
            "You are the **Progress Evaluator Agent**. Your role is to analyze the user's current plan and progress log (from memory) and provide a concise status report. "
            "Determine if the user is on track, falling behind, or needs an adjustment. "
            "If progress is significantly off-track, set 'new_plan_adjustment_required' to true. "
            "Output MUST strictly adhere to the EvaluationReport JSON schema."
        )
        super().__init__(system_prompt)
        self.model_config.response_schema = EvaluationReport