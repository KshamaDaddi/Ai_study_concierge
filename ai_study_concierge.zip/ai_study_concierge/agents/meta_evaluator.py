from .base_agent import BaseAgent, BaseModel
from typing import Dict, Any, List

# --- Agent Output Schema ---
class MetaEvaluationDecision(BaseModel):
    final_user_response: str
    next_agent_to_call: str # e.g., "StudyPlanner", "Scheduler", "Evaluator", or "STOP"
    memory_update: Dict[str, Any] # Data to store in memory for the next session

class MetaEvaluatorAgent(BaseAgent):
    def __init__(self):
        system_prompt = (
            "You are the **Meta-Evaluator Agent**. You are the final decision-maker and the user-facing interface. "
            "Your task is to review the output of the previous agent, craft a clear, conversational, and actionable response for the user, and determine the next logical step in the multi-agent workflow. "
            "If the workflow is complete for now, set 'next_agent_to_call' to 'STOP'. "
            "Ensure 'memory_update' contains all critical plan details to persist. "
            "Output MUST strictly adhere to the MetaEvaluationDecision JSON schema."
        )
        super().__init__(system_prompt)
        self.model_config.response_schema = MetaEvaluationDecision