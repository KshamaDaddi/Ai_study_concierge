from .base_agent import BaseAgent, BaseModel
from typing import List, Dict

# --- Tool Input Schema (imported from tools/calendar_tool.py) ---
from tools.calendar_tool import CalendarEvent, CalendarTool

# --- Agent Output Schema ---
class SchedulingSummary(BaseModel):
    message: str
    events_created_count: int
    calendar_response_log: List[str]
    document_response_log: str

class SchedulerAgent(BaseAgent):
    def __init__(self):
        # Tools: Google Calendar for scheduling, Document Generator for plan summary
        calendar_tool = CalendarTool()
        from tools.doc_generator import DocumentGenerator
        doc_generator = DocumentGenerator()
        
        system_prompt = (
            "You are the **Scheduler/Calendar Agent**. Your primary task is to take a complete Study or Project Plan and convert it into scheduled calendar events, "
            "adhering to the user's daily commitment hours and timeline. You must use the `create_event` tool for **all** scheduled tasks. "
            "After scheduling, use the `generate_pdf` tool to create a summary document of the full plan. "
            "Output MUST strictly adhere to the SchedulingSummary JSON schema."
        )
        super().__init__(system_prompt, tools=[calendar_tool.create_event, doc_generator.generate_pdf])
        self.model_config.response_schema = SchedulingSummary