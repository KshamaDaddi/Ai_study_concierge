from .base_agent import BaseAgent, BaseModel
from typing import List, Dict

# --- Agent Output Schema ---
class GoalAnalysisOutput(BaseModel):
    user_goal_summary: str
    timeline_months: int
    daily_commitment_hours: float
    required_domains: List[str]
    initial_preferences: Dict[str, str]

class GoalAnalyzerAgent(BaseAgent):
    def __init__(self):
        system_prompt = (
            "You are the **Goal Understanding Agent**. Your role is to parse a user's free-form goal into a structured format. "
            "Analyze the input to extract the main objective, duration, time commitment, and primary knowledge areas. "
            "Output MUST strictly adhere to the GoalAnalysisOutput JSON schema."
        )
        super().__init__(system_prompt)
        
        # Update model config with specific JSON schema
        self.model_config.response_schema = GoalAnalysisOutput