from .base_agent import BaseAgent, BaseModel
from typing import List

# --- Agent Output Schema ---
class ProjectMilestone(BaseModel):
    milestone_name: str
    estimated_days: int
    tasks: List[str]
    delivery_date: str # YYYY-MM-DD format

class ProjectPlanOutput(BaseModel):
    project_title: str
    description: str
    milestones: List[ProjectMilestone]
    tech_stack: List[str]

class ProjectBuilderAgent(BaseAgent):
    def __init__(self):
        # Tools: Web Search to find project ideas/latest tech
        from tools.search_tool import SearchTool
        search_tool = SearchTool()
        system_prompt = (
            "You are the **Project Builder Agent**. Your task is to design a high-level project plan based on the user's goal (if it's project-focused). "
            "Define the project, break it into clear milestones with tasks, and suggest a modern technology stack. "
            "Use the SearchTool to validate project feasibility and get cutting-edge tech recommendations. "
            "Output MUST strictly adhere to the ProjectPlanOutput JSON schema."
        )
        super().__init__(system_prompt, tools=[search_tool.web_search])
        self.model_config.response_schema = ProjectPlanOutput