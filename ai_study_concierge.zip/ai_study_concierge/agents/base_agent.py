from google import genai
from google.genai import types
from config import GEMINI_API_KEY, GEMINI_MODEL, TEMPERATURE
from typing import List, Callable, Optional, Dict, Any
from pydantic import BaseModel
import json

class BaseAgent:
    def __init__(self, system_prompt: str, tools: Optional[List[Callable]] = None):
        self.client = genai.Client(api_key=GEMINI_API_KEY)
        self.system_prompt = system_prompt
        self.tools = tools if tools is not None else []
        self.model_name = GEMINI_MODEL
        
        self.model_config = types.GenerateContentConfig(
            temperature=TEMPERATURE,
            # Enable tool use if tools are provided
            tools=self.tools if self.tools else None,
            response_mime_type="application/json", # Agents will primarily output JSON structures
        )

    def generate_response(self, user_prompt: str, context: Dict[str, Any]) -> str:
        """
        Generates a structured response from the agent, handling tool calls.
        
        :param user_prompt: The specific task/input for this agent.
        :param context: The current memory/session data.
        :return: The JSON output from the agent, potentially after tool execution.
        """
        full_prompt = (
            f"SYSTEM CONTEXT:\n{self.system_prompt}\n\n"
            f"CURRENT SESSION MEMORY:\n{json.dumps(context, indent=2)}\n\n"
            f"USER INPUT / TASK:\n{user_prompt}\n\n"
            "---"
            "Your output MUST be a single JSON object that conforms to the required output schema."
        )

        try:
            # First call to generate the content (which might include a tool call)
            response = self.client.models.generate_content(
                model=self.model_name,
                contents=full_prompt,
                config=self.model_config
            )

            # --- Tool Calling Logic ---
            if response.function_calls:
                tool_results = []
                for call in response.function_calls:
                    # Find and execute the actual Python function
                    tool_func = next((t for t in self.tools if t.__name__ == call.name), None)
                    if tool_func:
                        # Pydantic validation and execution
                        tool_input_schema = tool_func.__annotations__['event_data'] if 'event_data' in tool_func.__annotations__ else tool_func.__annotations__['doc_content'] if 'doc_content' in tool_func.__annotations__ else tool_func.__annotations__['search_query']
                        validated_input = tool_input_schema(**dict(call.args))
                        
                        tool_output = tool_func(validated_input)
                        
                        tool_results.append(types.Part.from_function_response(
                            name=call.name,
                            response={"result": tool_output}
                        ))
                    
                # Second call with tool results
                second_response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=[full_prompt, response.candidates[0].content, *tool_results],
                    config=self.model_config
                )
                return second_response.text
            
            return response.text

        except Exception as e:
            return json.dumps({"error": f"Agent failed to generate response or execute tool: {e}"})