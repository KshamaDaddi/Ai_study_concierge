from .base_agent import BaseAgent, BaseModel
from typing import List

# --- Agent Output Schema ---
class StudyPlanStep(BaseModel):
    topic: str
    duration_days: int
    resources: List[str]
    target_date: str # YYYY-MM-DD format

class StudyPlanOutput(BaseModel):
    plan_title: str
    total_duration_days: int
    phases: List[StudyPlanStep]
    next_action_required: str # e.g., "Schedule the first 3 phases."

class StudyPlannerAgent(BaseAgent):
    def __init__(self):
        # Tools: Web Search to get up-to-date curriculum/resources
        from tools.search_tool import SearchTool
        search_tool = SearchTool()
        system_prompt = (
            "You are the **Study Planner Agent**. Your task is to take the analyzed user goal and generate a detailed, phased study plan. "
            "Break the goal into sequential topics, allocate time based on the user's commitment/timeline, and suggest specific resources. "
            "Use the SearchTool to find current, high-quality resources for the required domains before finalizing the plan. "
            "Output MUST strictly adhere to the StudyPlanOutput JSON schema."
        )
        super().__init__(system_prompt, tools=[search_tool.web_search])
        self.model_config.response_schema = StudyPlanOutput